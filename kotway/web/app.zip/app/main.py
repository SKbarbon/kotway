from kotway import UnitType
import kotway, time

def main (page: kotway.Page):
    page.current_view.place_items = kotway.Alignment.CENTER
    page.current_view.display = kotway.DisplayType.GRID
    page.current_view.flex = kotway.Flex(1)

    input = kotway.TextField(value="0", text_align=kotway.Alignment.CENTER, width=100,
                             on_input=lambda e: print(input.value), margin=5)

    def minus_click(e):
        input.value = str(int(input.value) - 1)
        input.update()

    def plus_click(e):
        input.value = str(int(input.value) + 1)
        input.update()

    page.current_view.add_control(kotway.Container(
        controls=[
            kotway.Button(controls=[kotway.Text("+")], on_click=plus_click),
            input,
            kotway.Button(controls=[kotway.Text("-")], on_click=minus_click)
        ],
        display=kotway.DisplayType.FLEX,
        flex_direction=kotway.FlexDirection.ROW,
        justify_content=kotway.Alignment.CENTER,
        align_items=kotway.Alignment.CENTER
    ))

    page.update()

import sys

adapter = None
if "pyodide" in sys.modules:
    adapter = kotway.PyodideAdapter()
kotway.App(main, custom_adapter=adapter).run(port=8000)